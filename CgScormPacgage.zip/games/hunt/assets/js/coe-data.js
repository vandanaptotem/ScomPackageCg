var game = {};
game.data = [
    {
        statement: "What's the capital of India?",
        weight: 1,

        opta: "Delhi",
        optacorrect: "true",
        optapoints: "10",

        optb: "Mumbai",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "Chennai",
        optccorrect: "false",
        optcpoints: "0",

        optd: "Bengaluru",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "Where is Gateway of India Located?",
        weight: 1,

        opta: "Delhi",
        optacorrect: "false",
        optapoints: "0",

        optb: "Mumbai",
        optbcorrect: "true",
        optbpoints: "10",

        optc: "Pune",
        optccorrect: "false",
        optcpoints: "0",

        optd: "Bengaluru",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "Where is India Gate located?",
        weight: 1,

        opta: "Delhi",
        optacorrect: "true",
        optapoints: "10",

        optb: "Agra",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "Patna",
        optccorrect: "false",
        optcpoints: "0",

        optd: "Shimla",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "Where is the Bay of Bengal?",
        weight: 1,

        opta: "East of India",
        optacorrect: "true",
        optapoints: "10",

        optb: "West of India",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "North of India",
        optccorrect: "false",
        optcpoints: "0",

        optd: "South of India",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "Where is Charminar located?",
        weight: 1,

        opta: "Hyderabad",
        optacorrect: "true",
        optapoints: "10",

        optb: "Chennai",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "Mysore",
        optccorrect: "false",
        optcpoints: "0",

        optd: "Patna",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "Where is Kamatipura?",
        weight: 1,

        opta: "Delhi",
        optacorrect: "false",
        optapoints: "0",

        optb: "Pune",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "Mumbai",
        optccorrect: "true",
        optcpoints: "10",

        optd: "Goa",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "Where are the Sunderbans located?",
        weight: 1,

        opta: "West Bengal",
        optacorrect: "true",
        optapoints: "10",

        optb: "Tamil Nadu",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "Gujarat",
        optccorrect: "false",
        optcpoints: "0",

        optd: "Himachal Pradesh",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "Who is the Father of Our Nation?",
        weight: 1,

        opta: "Mahatma Gandhi",
        optacorrect: "true",
        optapoints: "10",

        optb: "Jawaharlal Nehru",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "Nathuram Godse",
        optccorrect: "false",
        optcpoints: "0",

        optd: "Lee Harvey Oswald",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "Highest Peak in India?",
        weight: 1,

        opta: "Mount Everest",
        optacorrect: "false",
        optapoints: "0",

        optb: "Mount Kanchendzonga",
        optbcorrect: "true",
        optbpoints: "10",

        optc: "Gilbert Hill",
        optccorrect: "false",
        optcpoints: "0",

        optd: "Deccan Plateau",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    },
    {
        statement: "What is the traditional Drink of Goa?",
        weight: 1,

        opta: "Penny",
        optacorrect: "false",
        optapoints: "0",

        optb: "Jenny",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "Kenny",
        optccorrect: "false",
        optcpoints: "0",

        optd: "Fenny",
        optdcorrect: "true",
        optdpoints: "10",

        slide_id:321
    },
    {
        statement: "Who was called the Nightingale of India?",
        weight: 1,

        opta: "Asha Bhosle",
        optacorrect: "false",
        optapoints: "0",

        optb: "Alisha Chinoy",
        optbcorrect: "false",
        optbpoints: "0",

        optc: "Sarojini Naidu",
        optccorrect: "true",
        optcpoints: "10",

        optd: "Lady GaGa",
        optdcorrect: "false",
        optdpoints: "0",

        slide_id:321
    }
];



