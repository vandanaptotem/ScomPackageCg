# hangman
Ptotem Learning Projects (c) 2015.
