
window = {};

window.data = [
    {loc: "diva", description: "<span>This is Div A</span>", sequence: 4},
    {loc: "divb", description: "<span>This is Div B This is Div B This is Div B This is Div B This is Div B This is Div B This is Div B This is Div B This is Div B This is Div B This is Div B This is Div B </span>", sequence: 2},
    {loc: "divc", description: "<span>This is Div C</span>", sequence: 3},
    {loc: "divb", description: "<img src='img/arrow.png'/>", sequence: 10}
]